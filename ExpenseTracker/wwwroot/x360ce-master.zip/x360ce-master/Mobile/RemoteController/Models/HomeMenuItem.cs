﻿namespace JocysCom.RemoteController.Models
{

	public class HomeMenuItem
	{
		public MenuItemType MenuType { get; set; }

		public string Title { get; set; }

		public System.Type PageType { get; set; }
	}
}
