﻿namespace JocysCom.RemoteController.Models
{
	public enum MenuItemType
	{
		Controller,
		Security,
		Settings,
		About,
	}
}
