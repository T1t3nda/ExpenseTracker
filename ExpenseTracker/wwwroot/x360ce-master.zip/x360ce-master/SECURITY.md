# Security Policy

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to
**[support@x360ce.com](mailto:support@x360ce.com)**
