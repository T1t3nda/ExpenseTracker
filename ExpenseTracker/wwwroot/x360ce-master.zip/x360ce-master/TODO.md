# TODO and Known issues

- Feature Request: Add the capability to record joystick actions (controller state changes). This could be used by gamers to track their 'actions per minute'.
- Feature: Add a hotkey to toggle emulation on/off.
