﻿namespace x360ce.App
{
	public enum NavImageType
	{
		Normal,
		Record,
		Active,
		Over
	}
}
