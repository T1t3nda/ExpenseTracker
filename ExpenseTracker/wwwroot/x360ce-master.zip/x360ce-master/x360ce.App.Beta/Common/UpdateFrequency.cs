﻿namespace x360ce.App
{
	public enum UpdateFrequency: int
	{
		ms1_1000Hz = 1,
		ms2_500Hz = 2,
		//ms3_333Hz = 3,
		ms4_250Hz = 4,
		//ms5_200Hz = 5,
		//ms6_166Hz = 6,
		//ms7_142Hz = 7,
		ms8_125Hz = 8,
	}
}
