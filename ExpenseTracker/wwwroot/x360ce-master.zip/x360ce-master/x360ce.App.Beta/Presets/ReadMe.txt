﻿Preset will be included in "Presets:" ListBox only if 
"Build Action" property of file is set to "Embedded Resource" in Visual Studio.