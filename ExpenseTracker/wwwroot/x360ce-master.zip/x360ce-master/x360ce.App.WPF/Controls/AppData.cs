﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace x360ce.App.Controls
{
    class AppData
    {

        //#region Static JocysTime data available to all app
        //static object ControllerButtonsLock = new object();

        //static List<ControllerButtonItem> _JocysButtons;

        //public static List<ControllerButtonItem> JocysButtons
        //{
        //    get
        //    {
        //        lock (ControllerButtonsLock)
        //        {
        //            if (_JocysButtons == null)
        //            {
        //                var list = new List<ControllerButtonItem>();
        //                list.Add(new ControllerButtonItem("Name", "Title"));
        //                _JocysButtons = list;
        //            }
        //            return _JocysButtons;
        //        }
        //    }
        //}

        ////public StackPanel ColorDStackPanel { get; private set; }
        //#endregion


    }
}
