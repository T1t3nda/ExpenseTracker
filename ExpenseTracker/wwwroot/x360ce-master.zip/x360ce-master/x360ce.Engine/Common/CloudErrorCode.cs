﻿namespace x360ce.Engine

{
	public enum CloudErrorCode: int
	{
		None = 0,
		Error = 1,
		UnableToDecrypt = -2147024809,
	}
}
