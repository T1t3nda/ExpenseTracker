﻿namespace x360ce.Engine
{
	public enum EmulationType
	{
		None = 0,
		Library = 1,
		Virtual = 2,
	}
}
