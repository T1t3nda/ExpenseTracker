﻿namespace x360ce.Engine
{
   public enum EnabledState
    {
       None = 0,
       Enabled = 1,
       Disabled = 2,
    }
}
