﻿using System;

namespace x360ce.Engine
{
	public interface IChecksum
	{
		Guid Checksum { get; set; }
	}
}
