﻿using System;

namespace x360ce.Engine
{
    public interface IDateTime
    {
        DateTime DateCreated { get; set; }
        DateTime DateUpdated { get; set; }

    }
}
