﻿namespace JocysCom.ClassLibrary
{
	public enum TimeUnitType
	{
		None = 0,
		Seconds = 1,
		Minutes = 2,
		Hours = 3,
		Days = 4,
	}
}
